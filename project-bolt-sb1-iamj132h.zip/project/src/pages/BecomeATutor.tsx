import React, { useState } from 'react';
import { BookOpen, Calendar, DollarSign, Users, Check } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Textarea from '../components/ui/Textarea';
import { toast } from 'sonner';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const subjects = [
  'Mathematics', 'Physics', 'Chemistry', 'Biology',
  'English', 'History', 'Computer Science', 'Foreign Languages',
  'Economics', 'Psychology', 'Statistics', 'Engineering'
];

export default function BecomeATutor() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    university: '',
    graduationYear: '',
    subjects: [] as string[],
    bio: '',
    experience: '',
    availability: [] as string[],
  });
  
  const [loading, setLoading] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleSubjectToggle = (subject: string) => {
    setFormData((prev) => ({
      ...prev,
      subjects: prev.subjects.includes(subject)
        ? prev.subjects.filter(s => s !== subject)
        : [...prev.subjects, subject]
    }));
  };
  
  const handleAvailabilityToggle = (day: string) => {
    setFormData((prev) => ({
      ...prev,
      availability: prev.availability.includes(day)
        ? prev.availability.filter(d => d !== day)
        : [...prev.availability, day]
    }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Insert application into database
      const { error: dbError } = await supabase
        .from('tutor_applications')
        .insert([formData]);

      if (dbError) throw dbError;

      // Send confirmation email
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-tutor-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          email: formData.email,
          name: formData.name,
          type: 'confirmation',
        }),
      });

      if (!response.ok) throw new Error('Failed to send confirmation email');
      
      toast.success('Your application has been submitted successfully! Please check your email for confirmation.');
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        phone: '',
        university: '',
        graduationYear: '',
        subjects: [],
        bio: '',
        experience: '',
        availability: [],
      });
    } catch (error) {
      console.error(error);
      toast.error('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  
  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Become a StudyBridge Tutor
          </h1>
          <p className="text-xl text-gray-600">
            Share your knowledge, help others learn, and make a difference in students' lives.
          </p>
        </div>
        
        {/* Benefits */}
        <div className="max-w-5xl mx-auto mb-16">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Calendar className="h-10 w-10 text-blue-600" />,
                title: "Flexible Schedule",
                description: "Create your own tutoring schedule that works around your classes and other commitments."
              },
              {
                icon: <Users className="h-10 w-10 text-blue-600" />,
                title: "Help Others",
                description: "Make a meaningful impact by helping students achieve their academic goals."
              },
              {
                icon: <BookOpen className="h-10 w-10 text-blue-600" />,
                title: "Build Experience",
                description: "Gain valuable teaching experience and develop communication skills that employers value."
              }
            ].map((benefit, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 border border-gray-100">
                <div className="flex items-center mb-4">
                  <div className="p-2 bg-blue-50 rounded-lg mr-4">
                    {benefit.icon}
                  </div>
                  <h3 className="font-semibold text-lg">{benefit.title}</h3>
                </div>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
        
        {/* Application Form */}
        <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-lg p-8 border border-gray-200">
          <h2 className="text-2xl font-bold mb-6 text-gray-900">Tutor Application</h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Input
                label="Full Name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="John Doe"
              />
              
              <Input
                label="Email"
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="you@example.com"
              />
              
              <Input
                label="Phone Number"
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                placeholder="(123) 456-7890"
              />
              
              <Input
                label="University/College"
                name="university"
                value={formData.university}
                onChange={handleChange}
                required
                placeholder="Stanford University"
              />
              
              <Input
                label="Expected Graduation Year"
                type="number"
                name="graduationYear"
                value={formData.graduationYear}
                onChange={handleChange}
                required
                placeholder="2024"
                min="2023"
                max="2030"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Subjects You Can Teach<span className="text-red-500 ml-1">*</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {subjects.map((subject) => (
                  <div
                    key={subject}
                    onClick={() => handleSubjectToggle(subject)}
                    className={`cursor-pointer rounded-md px-3 py-2 text-sm font-medium transition-colors border ${
                      formData.subjects.includes(subject)
                        ? 'bg-blue-100 border-blue-300 text-blue-700'
                        : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {formData.subjects.includes(subject) && (
                      <Check className="inline-block h-4 w-4 mr-1" />
                    )}
                    {subject}
                  </div>
                ))}
              </div>
              {formData.subjects.length === 0 && (
                <p className="mt-1 text-sm text-red-600">Please select at least one subject</p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Availability<span className="text-red-500 ml-1">*</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {days.map((day) => (
                  <div
                    key={day}
                    onClick={() => handleAvailabilityToggle(day)}
                    className={`cursor-pointer rounded-md px-3 py-2 text-sm font-medium transition-colors border ${
                      formData.availability.includes(day)
                        ? 'bg-blue-100 border-blue-300 text-blue-700'
                        : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {formData.availability.includes(day) && (
                      <Check className="inline-block h-4 w-4 mr-1" />
                    )}
                    {day}
                  </div>
                ))}
              </div>
              {formData.availability.length === 0 && (
                <p className="mt-1 text-sm text-red-600">Please select at least one day</p>
              )}
            </div>
            
            <Textarea
              label="Bio"
              name="bio"
              value={formData.bio}
              onChange={handleChange}
              required
              placeholder="Tell us about yourself, your academic background, and why you want to be a tutor."
              rows={4}
            />
            
            <Textarea
              label="Teaching Experience"
              name="experience"
              value={formData.experience}
              onChange={handleChange}
              placeholder="Describe any previous teaching or tutoring experience you have (if any)."
              rows={4}
            />
            
            <div className="flex items-center">
              <input
                id="agree-terms"
                name="agree-terms"
                type="checkbox"
                required
                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <label htmlFor="agree-terms" className="ml-2 block text-sm text-gray-700">
                I agree to the{" "}
                <a href="/terms" className="text-blue-600 hover:text-blue-500">
                  Terms of Service
                </a>{" "}
                and{" "}
                <a href="/privacy" className="text-blue-600 hover:text-blue-500">
                  Privacy Policy
                </a>
              </label>
            </div>
            
            <Button
              type="submit"
              disabled={loading || formData.subjects.length === 0 || formData.availability.length === 0}
              className="w-full md:w-auto"
            >
              {loading ? 'Submitting application...' : 'Submit Application'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}