import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Users, Calendar, ArrowRight, CheckCircle } from 'lucide-react';
import Button from '../components/ui/Button';

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-28 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="max-w-xl">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
                Connect with Expert Tutors from Top Universities
              </h1>
              <p className="mt-6 text-xl text-gray-700">
                StudyBridge connects college students with learners for personalized tutoring sessions. Get the academic support you need, online or in-person.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Button to="/auth" size="lg">
                  Get Started
                </Button>
                <Button to="/become-a-tutor" variant="outline" size="lg">
                  Become a Tutor
                </Button>
              </div>

              <div className="mt-10 flex flex-wrap items-center gap-6">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                  <span className="text-gray-700">100% Free</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                  <span className="text-gray-700">Expert Tutors</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                  <span className="text-gray-700">Flexible Scheduling</span>
                </div>
              </div>
            </div>
            <div className="hidden md:block relative">
              <div className="absolute inset-0 bg-blue-600 rounded-lg transform translate-x-4 translate-y-4"></div>
              <img
                src="https://images.pexels.com/photos/5905498/pexels-photo-5905498.jpeg"
                alt="Students learning"
                className="relative z-10 rounded-lg shadow-xl w-full h-auto max-h-[500px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              How StudyBridge Works
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Get matched with the perfect tutor in 3 simple steps
            </p>
          </div>

          <div className="mt-16 grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Users className="h-10 w-10 text-blue-600" />,
                title: "Find Your Match",
                description: "Browse through our qualified tutors, filter by subject, and read reviews to find your perfect match."
              },
              {
                icon: <Calendar className="h-10 w-10 text-blue-600" />,
                title: "Schedule Sessions",
                description: "Book sessions at times that work for you, whether it's a one-off help or regular weekly meetings."
              },
              {
                icon: <BookOpen className="h-10 w-10 text-blue-600" />,
                title: "Learn & Succeed",
                description: "Connect online or in-person, get personalized help, and achieve your academic goals."
              }
            ].map((feature, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-8 transition-transform hover:transform hover:-translate-y-1">
                <div className="inline-block p-3 bg-blue-100 rounded-lg mb-5">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Explore Subjects
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              From math to language arts, we've got tutors for every subject
            </p>
          </div>

          <div className="mt-12 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[
              "Mathematics", "Physics", "Chemistry", "Biology",
              "English", "History", "Computer Science", "Foreign Languages",
              "Economics", "Psychology", "Statistics", "Engineering"
            ].map((subject, index) => (
              <a
                key={index}
                href="#"
                className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:border-blue-500 hover:shadow-md transition-all flex items-center justify-between"
              >
                <span className="font-medium">{subject}</span>
                <ArrowRight className="h-4 w-4 text-blue-600" />
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold">
              Ready to Boost Your Academic Performance?
            </h2>
            <p className="mt-4 text-xl opacity-90">
              Join StudyBridge today and connect with expert tutors for free!
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button 
                to="/auth" 
                variant="ghost" 
                size="lg"
                className="bg-white hover:bg-gray-100 text-blue-600"
              >
                Get Started
              </Button>
              <Button 
                to="/become-a-tutor" 
                variant="outline" 
                size="lg"
                className="border-white text-white hover:bg-white hover:text-blue-600"
              >
                Become a Tutor
              </Button>
            </div>
            <div className="mt-10 flex flex-col sm:flex-row justify-center items-center gap-4 text-sm">
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                <span>Flexible scheduling</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                <span>Verified expert tutors</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                <span>100% Free</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}