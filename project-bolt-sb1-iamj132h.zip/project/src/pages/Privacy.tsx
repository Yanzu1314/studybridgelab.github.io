import React from 'react';
import { Shield, Eye, Lock, Server } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Privacy Policy
            </h1>
            <p className="text-xl text-gray-600">
              Last updated: June 1, 2023
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8 border border-gray-200">
            <div className="prose prose-blue max-w-none">
              <p>
                StudyBridge ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our tutoring platform.
              </p>
              <p>
                Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the site.
              </p>
              
              <h2 id="collection-of-information">1. Collection of Information</h2>
              <p>
                We collect information about you in various ways when you use our platform:
              </p>
              
              <h3>1.1 Personal Data</h3>
              <p>
                We may collect personal information that you voluntarily provide to us when you:
              </p>
              <ul>
                <li>Register for an account</li>
                <li>Sign up for our newsletter</li>
                <li>Participate in tutoring sessions</li>
                <li>Contact us for support</li>
                <li>Complete forms on our website</li>
              </ul>
              <p>
                This information may include:
              </p>
              <ul>
                <li>Name</li>
                <li>Email address</li>
                <li>Phone number</li>
                <li>Educational background</li>
                <li>Profile photo</li>
              </ul>
              
              <h3>1.2 Academic Information</h3>
              <p>
                When you use our tutoring services, we may collect information about:
              </p>
              <ul>
                <li>Academic interests and goals</li>
                <li>Subjects you're studying</li>
                <li>Performance data and progress</li>
                <li>Session notes and feedback</li>
              </ul>
              
              <h3>1.3 Automatically Collected Information</h3>
              <p>
                When you visit our website or use our platform, we may automatically collect certain information about your device, including:
              </p>
              <ul>
                <li>IP address</li>
                <li>Browser type</li>
                <li>Operating system</li>
                <li>Device information</li>
                <li>Usage patterns and interactions</li>
                <li>Referral source</li>
              </ul>
              
              <h2 id="use-of-information">2. Use of Information</h2>
              <p>
                We may use the information we collect for various purposes, including to:
              </p>
              <ul>
                <li>Provide, maintain, and improve our services</li>
                <li>Match you with appropriate tutors</li>
                <li>Send administrative information, such as updates and security alerts</li>
                <li>Respond to your comments, questions, and requests</li>
                <li>Personalize your experience on our platform</li>
                <li>Monitor and analyze trends, usage, and activities</li>
                <li>Detect, prevent, and address technical issues or fraudulent activities</li>
                <li>Comply with legal obligations</li>
              </ul>
              
              <h2 id="sharing-of-information">3. Sharing of Information</h2>
              <p>
                We may share your information in the following situations:
              </p>
              
              <h3>3.1 With Tutors and Students</h3>
              <p>
                To facilitate tutoring sessions, we share limited profile information between tutors and students who are matched for sessions.
              </p>
              
              <h3>3.2 With Service Providers</h3>
              <p>
                We may share your information with third-party vendors, service providers, and other contractors who perform services for us or on our behalf.
              </p>
              
              <h3>3.3 Business Transfers</h3>
              <p>
                If we are involved in a merger, acquisition, or sale of all or a portion of our assets, your information may be transferred as part of that transaction.
              </p>
              
              <h3>3.4 Legal Requirements</h3>
              <p>
                We may disclose your information where required to do so by law or in response to valid requests by public authorities (e.g., a court or government agency).
              </p>
              
              <h3>3.5 With Your Consent</h3>
              <p>
                We may share your information with other third parties when we have your consent to do so.
              </p>
              
              <h2 id="data-security">4. Data Security</h2>
              <p>
                We have implemented appropriate technical and organizational security measures designed to protect the security of any personal information we process. However, please be aware that no method of transmission over the Internet or method of electronic storage is 100% secure.
              </p>
              
              <h2 id="data-retention">5. Data Retention</h2>
              <p>
                We will retain your personal information only for as long as is necessary for the purposes set out in this privacy policy, unless a longer retention period is required or permitted by law.
              </p>
              
              <h2 id="your-rights">6. Your Rights</h2>
              <p>
                Depending on your location, you may have certain rights regarding your personal information, including:
              </p>
              <ul>
                <li>The right to access the personal information we have about you</li>
                <li>The right to request correction of inaccurate personal information</li>
                <li>The right to request deletion of your personal information</li>
                <li>The right to object to processing of your personal information</li>
                <li>The right to request restriction of processing of your personal information</li>
                <li>The right to data portability</li>
                <li>The right to withdraw consent</li>
              </ul>
              <p>
                To exercise any of these rights, please contact us at studybridgelab@gmail.com.
              </p>
              
              <h2 id="children-privacy">7. Children's Privacy</h2>
              <p>
                Our platform is not intended for children under the age of 13. We do not knowingly collect personal information from children under 13. If we become aware that we have collected personal information from a child under 13 without verification of parental consent, we will take steps to remove that information from our servers.
              </p>
              
              <h2 id="changes-to-privacy-policy">8. Changes to This Privacy Policy</h2>
              <p>
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date at the top. You are advised to review this Privacy Policy periodically for any changes.
              </p>
              
              <h2 id="contact-us">9. Contact Us</h2>
              <p>
                If you have any questions about this Privacy Policy, please contact us at:
              </p>
              <p>
                Email: studybridgelab@gmail.com
              </p>
            </div>
          </div>
        </div>
        
        {/* Privacy Highlights */}
        <div className="max-w-5xl mx-auto mt-16">
          <h2 className="text-2xl font-bold text-center mb-10">Key Privacy Highlights</h2>
          
          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                icon: <Eye className="h-10 w-10 text-blue-600" />,
                title: "Data Collection",
                description: "We only collect information necessary to provide and improve our tutoring services."
              },
              {
                icon: <Server className="h-10 w-10 text-purple-600" />,
                title: "Data Usage",
                description: "Your data is used to personalize your experience and connect you with the right tutors."
              },
              {
                icon: <Lock className="h-10 w-10 text-teal-600" />,
                title: "Data Security",
                description: "We implement industry-standard security measures to protect your personal information."
              },
              {
                icon: <Shield className="h-10 w-10 text-red-600" />,
                title: "Your Control",
                description: "You maintain control over your personal data with access, correction, and deletion rights."
              }
            ].map((item, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 border border-gray-200 text-center">
                <div className="mx-auto w-16 h-16 flex items-center justify-center bg-gray-100 rounded-full mb-4">
                  {item.icon}
                </div>
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}