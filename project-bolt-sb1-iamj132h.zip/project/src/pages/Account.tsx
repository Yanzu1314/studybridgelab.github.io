import React, { useState } from 'react';
import { User, Clock, Calendar, CheckCircle, BookOpen, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import Button from '../components/ui/Button';

// Mock data
const upcomingSessions = [
  {
    id: 1,
    subject: 'Calculus II',
    tutor: 'Dr. Michael Chen',
    date: '2023-06-15',
    time: '3:00 PM - 4:00 PM',
    status: 'confirmed',
    online: true,
  },
  {
    id: 2,
    subject: 'Organic Chemistry',
    tutor: 'Sarah Johnson, PhD',
    date: '2023-06-18',
    time: '10:00 AM - 11:30 AM',
    status: 'pending',
    online: true,
  },
];

const pastSessions = [
  {
    id: 3,
    subject: 'Physics Mechanics',
    tutor: 'Dr. Michael Chen',
    date: '2023-06-01',
    time: '2:00 PM - 3:00 PM',
    status: 'completed',
    online: true,
    rating: 5,
  },
  {
    id: 4,
    subject: 'Statistics',
    tutor: 'Emma Thompson',
    date: '2023-05-28',
    time: '4:00 PM - 5:00 PM',
    status: 'completed',
    online: false,
    rating: 4,
  },
  {
    id: 5,
    subject: 'Linear Algebra',
    tutor: 'James Wilson',
    date: '2023-05-25',
    time: '1:00 PM - 2:00 PM',
    status: 'completed',
    online: true,
    rating: 5,
  },
];

export default function Account() {
  const { user, logout } = useAuth();
  const { currentPlan } = useSubscription();
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'profile'>('upcoming');
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Confirmed
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Completed
          </span>
        );
      default:
        return null;
    }
  };
  
  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[...Array(5)].map((_, index) => (
          <svg
            key={index}
            className={`h-4 w-4 ${
              index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
            }`}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M10 15.585l-6.267 3.289a1 1 0 01-1.45-1.054l1.196-6.968-5.07-4.94a1 1 0 01.553-1.704l7.001-1.018 3.13-6.34a1 1 0 011.813 0l3.13 6.34 7.001 1.018a1 1 0 01.553 1.704l-5.07 4.94 1.196 6.968a1 1 0 01-1.45 1.054L10 15.585z"
              clipRule="evenodd"
            />
          </svg>
        ))}
      </div>
    );
  };
  
  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Account Dashboard</h1>
            <p className="text-gray-600 mt-2">
              Manage your profile, sessions, and subscription
            </p>
          </div>
          
          <div className="grid md:grid-cols-5 gap-8">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-20 w-20 rounded-full bg-blue-100 flex items-center justify-center mb-3">
                    <User className="h-10 w-10 text-blue-600" />
                  </div>
                  <h2 className="font-semibold text-lg">{user?.name}</h2>
                  <p className="text-gray-600 text-sm">{user?.email}</p>
                  
                  {currentPlan && (
                    <div className="mt-2 inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                      {currentPlan.charAt(0).toUpperCase() + currentPlan.slice(1)} Plan
                    </div>
                  )}
                </div>
                
                <div className="border-t border-gray-200 pt-4">
                  <button
                    onClick={() => setActiveTab('upcoming')}
                    className={`flex items-center w-full py-2 px-3 rounded-md mb-1 transition-colors ${
                      activeTab === 'upcoming'
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Calendar className="h-5 w-5 mr-3" />
                    Upcoming Sessions
                  </button>
                  
                  <button
                    onClick={() => setActiveTab('past')}
                    className={`flex items-center w-full py-2 px-3 rounded-md mb-1 transition-colors ${
                      activeTab === 'past'
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Clock className="h-5 w-5 mr-3" />
                    Past Sessions
                  </button>
                  
                  <button
                    onClick={() => setActiveTab('profile')}
                    className={`flex items-center w-full py-2 px-3 rounded-md mb-1 transition-colors ${
                      activeTab === 'profile'
                        ? 'bg-blue-50 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Settings className="h-5 w-5 mr-3" />
                    Profile Settings
                  </button>
                </div>
                
                <div className="border-t border-gray-200 pt-4">
                  <button
                    onClick={logout}
                    className="flex items-center w-full py-2 px-3 rounded-md text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <LogOut className="h-5 w-5 mr-3" />
                    Logout
                  </button>
                </div>
              </div>
              
              {/* Quick Links */}
              <div className="bg-white rounded-lg shadow-md p-6 mt-6">
                <h3 className="font-semibold mb-4">Quick Links</h3>
                <ul className="space-y-2">
                  <li>
                    <a href="/pricing" className="text-blue-600 hover:underline text-sm">
                      View Pricing Plans
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-blue-600 hover:underline text-sm">
                      Find a Tutor
                    </a>
                  </li>
                  <li>
                    <a href="/faq" className="text-blue-600 hover:underline text-sm">
                      Support & FAQ
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Main Content */}
            <div className="md:col-span-4">
              {activeTab === 'upcoming' && (
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold">Upcoming Sessions</h2>
                    <Button size="sm">Schedule New Session</Button>
                  </div>
                  
                  {upcomingSessions.length > 0 ? (
                    <div className="space-y-4">
                      {upcomingSessions.map((session) => (
                        <div
                          key={session.id}
                          className="bg-white rounded-lg shadow-md p-6 border border-gray-200"
                        >
                          <div className="flex flex-wrap gap-4 justify-between">
                            <div>
                              <div className="flex items-center mb-2">
                                <BookOpen className="h-5 w-5 text-blue-600 mr-2" />
                                <h3 className="font-semibold text-lg">
                                  {session.subject}
                                </h3>
                              </div>
                              <p className="text-gray-600 mb-1">
                                <span className="font-medium">Tutor:</span> {session.tutor}
                              </p>
                              <p className="text-gray-600 mb-1">
                                <span className="font-medium">Date:</span> {session.date}
                              </p>
                              <p className="text-gray-600 mb-1">
                                <span className="font-medium">Time:</span> {session.time}
                              </p>
                              <p className="text-gray-600 mb-1">
                                <span className="font-medium">Format:</span>{' '}
                                {session.online ? 'Online' : 'In-person'}
                              </p>
                              <div className="mt-3">{getStatusBadge(session.status)}</div>
                            </div>
                            
                            <div className="flex flex-col space-y-2">
                              {session.status === 'confirmed' && (
                                <Button variant="primary" size="sm">
                                  Join Session
                                </Button>
                              )}
                              <Button variant="outline" size="sm">
                                Reschedule
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-600">
                                Cancel
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-white rounded-lg shadow-md p-8 border border-gray-200 text-center">
                      <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        No upcoming sessions
                      </h3>
                      <p className="text-gray-600 mb-6">
                        You don't have any tutoring sessions scheduled.
                      </p>
                      <Button>Schedule Your First Session</Button>
                    </div>
                  )}
                </div>
              )}
              
              {activeTab === 'past' && (
                <div>
                  <h2 className="text-xl font-semibold mb-6">Past Sessions</h2>
                  
                  {pastSessions.length > 0 ? (
                    <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Subject
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Tutor
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Date & Time
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Format
                            </th>
                            <th
                              scope="col"
                              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                            >
                              Rating
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {pastSessions.map((session) => (
                            <tr key={session.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">
                                  {session.subject}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">{session.tutor}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">{session.date}</div>
                                <div className="text-sm text-gray-500">{session.time}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">
                                  {session.online ? 'Online' : 'In-person'}
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                {renderStars(session.rating)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="bg-white rounded-lg shadow-md p-8 border border-gray-200 text-center">
                      <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">
                        No past sessions
                      </h3>
                      <p className="text-gray-600">
                        You haven't completed any tutoring sessions yet.
                      </p>
                    </div>
                  )}
                </div>
              )}
              
              {activeTab === 'profile' && (
                <div>
                  <h2 className="text-xl font-semibold mb-6">Profile Settings</h2>
                  
                  <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200 mb-8">
                    <h3 className="font-medium text-lg mb-4">Personal Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Full Name
                        </label>
                        <input
                          type="text"
                          value={user?.name}
                          className="w-full p-2 border border-gray-300 rounded-md"
                          readOnly
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Email
                        </label>
                        <input
                          type="email"
                          value={user?.email}
                          className="w-full p-2 border border-gray-300 rounded-md"
                          readOnly
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          placeholder="Add your phone number"
                          className="w-full p-2 border border-gray-300 rounded-md"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Education Level
                        </label>
                        <select className="w-full p-2 border border-gray-300 rounded-md">
                          <option>Select education level</option>
                          <option>High School</option>
                          <option>Undergraduate</option>
                          <option>Graduate</option>
                          <option>Other</option>
                        </select>
                      </div>
                    </div>
                    <div className="mt-6">
                      <Button>Save Changes</Button>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200 mb-8">
                    <h3 className="font-medium text-lg mb-4">Subscription</h3>
                    {currentPlan ? (
                      <div>
                        <p className="mb-4">
                          You are currently on the{' '}
                          <span className="font-semibold">
                            {currentPlan.charAt(0).toUpperCase() + currentPlan.slice(1)} Plan
                          </span>
                        </p>
                        <div className="flex gap-3">
                          <Button variant="outline" to="/pricing">
                            Change Plan
                          </Button>
                          <Button variant="ghost" className="text-red-600">
                            Cancel Subscription
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <p className="mb-4">You don't have an active subscription.</p>
                        <Button to="/pricing">View Plans</Button>
                      </div>
                    )}
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
                    <h3 className="font-medium text-lg mb-4">Password</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Current Password
                        </label>
                        <input
                          type="password"
                          className="w-full p-2 border border-gray-300 rounded-md"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          New Password
                        </label>
                        <input
                          type="password"
                          className="w-full p-2 border border-gray-300 rounded-md"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Confirm New Password
                        </label>
                        <input
                          type="password"
                          className="w-full p-2 border border-gray-300 rounded-md"
                        />
                      </div>
                    </div>
                    <div className="mt-6">
                      <Button>Update Password</Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}