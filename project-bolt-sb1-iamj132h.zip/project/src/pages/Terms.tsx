import React from 'react';
import { FileText, ShieldCheck, AlertTriangle, HelpCircle } from 'lucide-react';

export default function Terms() {
  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Terms of Service
            </h1>
            <p className="text-xl text-gray-600">
              Last updated: June 1, 2023
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8 border border-gray-200">
            <div className="prose prose-blue max-w-none">
              <p>
                Please read these Terms of Service ("Terms", "Terms of Service") carefully before using the StudyBridge website and tutoring platform operated by StudyBridge ("us", "we", or "our").
              </p>
              <p>
                Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who access or use the Service.
              </p>
              <p>
                By accessing or using the Service, you agree to be bound by these Terms. If you disagree with any part of the terms, you may not access the Service.
              </p>
              
              <h2 id="accounts">1. Accounts</h2>
              <p>
                When you create an account with us, you must provide information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.
              </p>
              <p>
                You are responsible for safeguarding the password that you use to access the Service and for any activities or actions under your password, whether your password is with our Service or a third-party service.
              </p>
              <p>
                You agree not to disclose your password to any third party. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.
              </p>
              
              <h2 id="use-license">2. Use License</h2>
              <p>
                StudyBridge grants you a personal, non-exclusive, non-transferable, limited license to use the Service for personal, non-commercial purposes in accordance with these Terms.
              </p>
              <p>
                You are not allowed to:
              </p>
              <ul>
                <li>Modify or copy any materials from the Service</li>
                <li>Use the materials for any commercial purpose or for any public display</li>
                <li>Attempt to decompile or reverse engineer any software contained on the Service</li>
                <li>Remove any copyright or other proprietary notations from the materials</li>
                <li>Transfer the materials to another person or "mirror" the materials on any other server</li>
              </ul>
              
              <h2 id="tutoring-services">3. Tutoring Services</h2>
              <p>
                StudyBridge is a platform that connects students with tutors. All tutoring services on our platform are currently provided free of charge. We believe in fostering a community of learners helping each other succeed.
              </p>
              
              <h2 id="account-responsibilities">4. Account Responsibilities</h2>
              <h3>4.1 For Students</h3>
              <p>
                As a student using our Service, you agree to:
              </p>
              <ul>
                <li>Provide accurate information about your academic needs</li>
                <li>Attend scheduled sessions on time or provide at least 24 hours notice for cancellations</li>
                <li>Use the Service for legitimate educational purposes only</li>
                <li>Respect the intellectual property rights of tutors and other users</li>
                <li>Provide honest feedback about your tutoring experience</li>
              </ul>
              
              <h3>4.2 For Tutors</h3>
              <p>
                As a tutor using our Service, you agree to:
              </p>
              <ul>
                <li>Provide accurate information about your qualifications and expertise</li>
                <li>Deliver high-quality tutoring services in your areas of expertise</li>
                <li>Be punctual for all scheduled sessions</li>
                <li>Respect the confidentiality of student information</li>
                <li>Adhere to our academic integrity policies</li>
                <li>Maintain a professional demeanor in all interactions</li>
              </ul>
              
              <h2 id="termination">5. Termination</h2>
              <p>
                We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
              </p>
              <p>
                Upon termination, your right to use the Service will immediately cease. If you wish to terminate your account, you may simply discontinue using the Service or contact us to request account deletion.
              </p>
              
              <h2 id="limitation-of-liability">6. Limitation of Liability</h2>
              <p>
                In no event shall StudyBridge, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:
              </p>
              <ul>
                <li>Your access to or use of or inability to access or use the Service</li>
                <li>Any conduct or content of any third party on the Service</li>
                <li>Any content obtained from the Service</li>
                <li>Unauthorized access, use or alteration of your transmissions or content</li>
              </ul>
              
              <h2 id="academic-integrity">7. Academic Integrity</h2>
              <p>
                StudyBridge is committed to upholding high standards of academic integrity. The Service is designed to help students learn and understand academic subjects, not to complete assignments or take exams on behalf of students.
              </p>
              <p>
                You agree not to use the Service to:
              </p>
              <ul>
                <li>Cheat on exams, tests, or quizzes</li>
                <li>Plagiarize academic work</li>
                <li>Submit work completed by a tutor as your own</li>
                <li>Violate any academic policies of your educational institution</li>
              </ul>
              
              <h2 id="changes">8. Changes</h2>
              <p>
                We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
              </p>
              
              <h2 id="contact-us">9. Contact Us</h2>
              <p>
                If you have any questions about these Terms, please contact us at:
              </p>
              <p>
                Email: studybridgelab@gmail.com
              </p>
            </div>
          </div>
        </div>
        
        {/* Key Terms Highlights */}
        <div className="max-w-5xl mx-auto mt-16">
          <h2 className="text-2xl font-bold text-center mb-10">Key Points to Remember</h2>
          
          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                icon: <FileText className="h-10 w-10 text-blue-600" />,
                title: "Personal Use Only",
                description: "Our platform is for personal, non-commercial educational purposes only."
              },
              {
                icon: <ShieldCheck className="h-10 w-10 text-green-600" />,
                title: "Academic Integrity",
                description: "We strictly enforce academic integrity - no cheating or plagiarism."
              },
              {
                icon: <AlertTriangle className="h-10 w-10 text-orange-600" />,
                title: "Account Responsibility",
                description: "You're responsible for all activity that occurs under your account."
              },
              {
                icon: <HelpCircle className="h-10 w-10 text-purple-600" />,
                title: "Support Available",
                description: "Our team is here to help with any questions about these terms."
              }
            ].map((item, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6 border border-gray-200 text-center">
                <div className="mx-auto w-16 h-16 flex items-center justify-center bg-gray-100 rounded-full mb-4">
                  {item.icon}
                </div>
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}