import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Home, Search } from 'lucide-react';
import Button from '../components/ui/Button';

export default function NotFound() {
  return (
    <div className="min-h-screen pt-20 pb-12 flex flex-col">
      <div className="flex-grow flex items-center justify-center container mx-auto px-4">
        <div className="max-w-lg w-full text-center">
          <div className="mb-8">
            <BookOpen className="h-20 w-20 text-blue-600 mx-auto" />
          </div>
          
          <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
          <h2 className="text-2xl font-semibold text-gray-700 mb-4">Page Not Found</h2>
          <p className="text-lg text-gray-600 mb-8">
            Oops! The page you're looking for doesn't exist or has been moved.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button to="/" className="flex items-center justify-center">
              <Home className="mr-2 h-5 w-5" />
              Back to Home
            </Button>
            <Button 
              variant="outline" 
              to="/contact"
              className="flex items-center justify-center"
            >
              <Search className="mr-2 h-5 w-5" />
              Help Me Find It
            </Button>
          </div>
          
          <div className="mt-12">
            <h3 className="font-medium text-lg mb-4">Popular pages you might be looking for:</h3>
            <div className="space-y-2">
              <Link to="/pricing" className="text-blue-600 hover:underline block">
                View Pricing Plans
              </Link>
              <Link to="/become-a-tutor" className="text-blue-600 hover:underline block">
                Become a Tutor
              </Link>
              <Link to="/faq" className="text-blue-600 hover:underline block">
                Frequently Asked Questions
              </Link>
              <Link to="/contact" className="text-blue-600 hover:underline block">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}