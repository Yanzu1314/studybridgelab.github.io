import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Users, Clock, BookOpen, X } from 'lucide-react';
import Button from '../components/ui/Button';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { toast } from 'sonner';

type Plan = 'basic' | 'premium';

const plans = [
  {
    id: 'basic',
    name: 'Basic Plan',
    price: 0,
    description: 'Perfect for students who need occasional tutoring help',
    features: [
      '4 tutoring sessions per month',
      'Access to recorded sessions',
      'Email support',
      'Homework help',
    ],
    notIncluded: [
      'Priority scheduling',
      'Subject specialists',
      'Guaranteed response time',
    ],
    color: 'blue',
    popular: false,
  },
  {
    id: 'premium',
    name: 'Premium Plan',
    price: 9.99,
    description: 'Comprehensive support for serious academic achievement',
    features: [
      'Unlimited tutoring sessions',
      'Access to recorded sessions',
      'Priority scheduling',
      'Subject specialists',
      '24/7 email & chat support',
      'Homework help',
      'Study guides & materials',
      'Guaranteed 2-hour response time',
      'Personalized learning plan',
    ],
    notIncluded: [],
    color: 'purple',
    popular: true,
  },
];

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annually'>('monthly');
  const { isAuthenticated } = useAuth();
  const { currentPlan, subscribe } = useSubscription();
  const navigate = useNavigate();
  
  const handleSubscribe = async (planId: Plan) => {
    if (!isAuthenticated) {
      // Redirect to auth page if not logged in
      navigate('/auth', { state: { from: '/pricing' } });
      return;
    }
    
    try {
      const success = await subscribe(planId);
      if (success) {
        navigate('/subscription-success');
        toast.success(`Successfully subscribed to the ${planId} plan!`);
      }
    } catch (error) {
      console.error(error);
      toast.error('Failed to process your subscription. Please try again.');
    }
  };
  
  const getDiscountedPrice = (basePrice: number) => {
    return billingCycle === 'annually' ? Math.round(basePrice * 0.8) : basePrice;
  };
  
  const getSavingsText = (basePrice: number) => {
    if (billingCycle === 'annually' && basePrice > 0) {
      const monthlyCost = getDiscountedPrice(basePrice);
      const annualCost = monthlyCost * 12;
      const regularCost = basePrice * 12;
      const savings = regularCost - annualCost;
      return `Save $${savings.toFixed(2)} per year`;
    }
    return null;
  };
  
  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Simple, Transparent Pricing
          </h1>
          <p className="text-xl text-gray-600">
            Choose the plan that fits your academic needs and goals.
          </p>
          
          {/* Billing toggle */}
          <div className="mt-8 inline-flex items-center p-1 bg-gray-100 rounded-lg">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-2 text-sm font-medium rounded-md ${
                billingCycle === 'monthly'
                  ? 'bg-white shadow-sm text-gray-900'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('annually')}
              className={`px-4 py-2 text-sm font-medium rounded-md flex items-center ${
                billingCycle === 'annually'
                  ? 'bg-white shadow-sm text-gray-900'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Annual Billing
              <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full">
                20% OFF
              </span>
            </button>
          </div>
        </div>
        
        {/* Pricing Cards */}
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8 mb-16">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative bg-white rounded-xl shadow-lg overflow-hidden border transform hover:-translate-y-1 transition-all duration-200 ${
                plan.popular ? 'md:scale-105 border-purple-200' : 'border-gray-200'
              }`}
            >
              {/* Popular badge */}
              {plan.popular && (
                <div className="absolute top-0 right-0 bg-purple-600 text-white py-1 px-4 text-sm font-medium">
                  Most Popular
                </div>
              )}
              
              <div className="p-8">
                <h3 className={`text-xl font-bold mb-2 ${
                  plan.color === 'blue' ? 'text-blue-600' : 'text-purple-600'
                }`}>
                  {plan.name}
                </h3>
                <p className="text-gray-600 mb-4 min-h-[48px]">{plan.description}</p>
                
                <div className="mb-6">
                  {plan.price === 0 ? (
                    <span className="text-4xl font-bold">Free</span>
                  ) : (
                    <>
                      <span className="text-4xl font-bold">${getDiscountedPrice(plan.price).toFixed(2)}</span>
                      <span className="text-gray-500">
                        /{billingCycle === 'monthly' ? 'month' : 'mo billed annually'}
                      </span>
                      
                      {billingCycle === 'annually' && (
                        <div className="mt-1">
                          <span className="text-green-600 text-sm font-medium">
                            {getSavingsText(plan.price)}
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </div>
                
                <Button
                  variant={plan.color === 'blue' ? 'primary' : 'secondary'}
                  fullWidth
                  onClick={() => handleSubscribe(plan.id as Plan)}
                >
                  {currentPlan === plan.id ? 'Current Plan' : 'Get Started'}
                </Button>
              </div>
              
              <div className="bg-gray-50 p-8">
                <h4 className="font-semibold text-gray-900 mb-4">What's included:</h4>
                <ul className="space-y-3">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                {plan.notIncluded.length > 0 && (
                  <>
                    <h4 className="font-semibold text-gray-900 mt-6 mb-4">Not included:</h4>
                    <ul className="space-y-3">
                      {plan.notIncluded.map((feature, idx) => (
                        <li key={idx} className="flex items-start text-gray-500">
                          <X className="h-5 w-5 text-gray-400 mr-2 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
        
        {/* Features */}
        <div className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-12">Why Choose StudyBridge?</h2>
          
          <div className="grid md:grid-cols-3 gap-x-16 gap-y-12">
            {[
              {
                icon: <Users className="h-10 w-10 text-blue-600" />,
                title: "Expert Tutors",
                description: "Our tutors are top college students from prestigious universities, thoroughly vetted for their knowledge and teaching abilities."
              },
              {
                icon: <Clock className="h-10 w-10 text-purple-600" />,
                title: "Flexible Scheduling",
                description: "Book sessions when you need them, with options for both online and in-person tutoring to fit your lifestyle."
              },
              {
                icon: <BookOpen className="h-10 w-10 text-teal-600" />,
                title: "Personalized Learning",
                description: "Get tailored help for your specific academic needs and learning style, not one-size-fits-all solutions."
              }
            ].map((feature, index) => (
              <div key={index}>
                <div className="mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
        
        {/* FAQ */}
        <div className="max-w-4xl mx-auto mt-20">
          <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          
          <div className="space-y-4">
            {[
              {
                question: "Can I switch plans later?",
                answer: "Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle."
              },
              {
                question: "Is there a satisfaction guarantee?",
                answer: "Absolutely! If you're not satisfied with your first session, we'll give you a full refund or schedule a session with a different tutor at no extra cost."
              },
              {
                question: "How do I schedule a session?",
                answer: "Once you've subscribed, you can browse available tutors, view their schedules, and book sessions directly through your account dashboard."
              },
              {
                question: "What if I don't use all my sessions in a month?",
                answer: "Basic plan sessions don't roll over to the next month. Premium plan members have unlimited sessions, so this isn't a concern."
              }
            ].map((item, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="font-semibold text-lg mb-2">{item.question}</h3>
                <p className="text-gray-700">{item.answer}</p>
              </div>
            ))}
          </div>
        </div>
        
        {/* CTA */}
        <div className="max-w-5xl mx-auto mt-20 text-center bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-12 text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to Excel in Your Studies?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of students who are achieving their academic goals with StudyBridge tutoring.
          </p>
          <Button 
            size="lg"
            className="bg-white text-blue-600 hover:bg-gray-100"
            to={isAuthenticated ? '/pricing' : '/auth'}
          >
            Get Started Today
          </Button>
        </div>
      </div>
    </div>
  );
}