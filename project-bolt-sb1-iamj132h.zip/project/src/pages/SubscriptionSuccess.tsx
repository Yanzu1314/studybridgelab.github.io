import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Calendar, ArrowRight } from 'lucide-react';
import Button from '../components/ui/Button';
import { useSubscription } from '../contexts/SubscriptionContext';

export default function SubscriptionSuccess() {
  const { currentPlan } = useSubscription();
  const navigate = useNavigate();
  
  // Redirect if no subscription
  useEffect(() => {
    if (!currentPlan) {
      navigate('/pricing');
    }
  }, [currentPlan, navigate]);
  
  if (!currentPlan) return null;
  
  const planInfo = {
    basic: {
      name: 'Basic Plan',
      sessions: '4 tutoring sessions per month',
      color: 'blue',
    },
    plus: {
      name: 'Plus Plan',
      sessions: '8 tutoring sessions per month',
      color: 'purple',
    },
    premium: {
      name: 'Premium Plan',
      sessions: 'Unlimited tutoring sessions',
      color: 'teal',
    },
  }[currentPlan];
  
  return (
    <div className="min-h-screen pt-20 pb-12 flex flex-col">
      <div className="flex-grow flex items-center justify-center container mx-auto px-4">
        <div className="max-w-lg w-full text-center">
          <div 
            className={`mx-auto w-20 h-20 rounded-full flex items-center justify-center mb-8 ${
              planInfo.color === 'blue' ? 'bg-blue-100' : 
              planInfo.color === 'purple' ? 'bg-purple-100' : 'bg-teal-100'
            }`}
          >
            <CheckCircle 
              className={`h-10 w-10 ${
                planInfo.color === 'blue' ? 'text-blue-600' : 
                planInfo.color === 'purple' ? 'text-purple-600' : 'text-teal-600'
              }`}
            />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Subscription Successful!
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Thank you for subscribing to StudyBridge's {planInfo.name}.
          </p>
          
          <div className="bg-white rounded-lg shadow-md p-8 border border-gray-200 mb-8">
            <h2 className="text-xl font-semibold mb-6">Subscription Details</h2>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div
                  className={`p-2 rounded-full mr-4 ${
                    planInfo.color === 'blue' ? 'bg-blue-100' : 
                    planInfo.color === 'purple' ? 'bg-purple-100' : 'bg-teal-100'
                  }`}
                >
                  <Calendar className={`h-6 w-6 ${
                    planInfo.color === 'blue' ? 'text-blue-600' : 
                    planInfo.color === 'purple' ? 'text-purple-600' : 'text-teal-600'
                  }`} />
                </div>
                <div className="text-left">
                  <h3 className="font-medium">Plan</h3>
                  <p className="text-gray-600">{planInfo.name}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div
                  className={`p-2 rounded-full mr-4 ${
                    planInfo.color === 'blue' ? 'bg-blue-100' : 
                    planInfo.color === 'purple' ? 'bg-purple-100' : 'bg-teal-100'
                  }`}
                >
                  <Calendar className={`h-6 w-6 ${
                    planInfo.color === 'blue' ? 'text-blue-600' : 
                    planInfo.color === 'purple' ? 'text-purple-600' : 'text-teal-600'
                  }`} />
                </div>
                <div className="text-left">
                  <h3 className="font-medium">Sessions</h3>
                  <p className="text-gray-600">{planInfo.sessions}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div
                  className={`p-2 rounded-full mr-4 ${
                    planInfo.color === 'blue' ? 'bg-blue-100' : 
                    planInfo.color === 'purple' ? 'bg-purple-100' : 'bg-teal-100'
                  }`}
                >
                  <Calendar className={`h-6 w-6 ${
                    planInfo.color === 'blue' ? 'text-blue-600' : 
                    planInfo.color === 'purple' ? 'text-purple-600' : 'text-teal-600'
                  }`} />
                </div>
                <div className="text-left">
                  <h3 className="font-medium">Billing Cycle</h3>
                  <p className="text-gray-600">Monthly</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div
                  className={`p-2 rounded-full mr-4 ${
                    planInfo.color === 'blue' ? 'bg-blue-100' : 
                    planInfo.color === 'purple' ? 'bg-purple-100' : 'bg-teal-100'
                  }`}
                >
                  <Calendar className={`h-6 w-6 ${
                    planInfo.color === 'blue' ? 'text-blue-600' : 
                    planInfo.color === 'purple' ? 'text-purple-600' : 'text-teal-600'
                  }`} />
                </div>
                <div className="text-left">
                  <h3 className="font-medium">Next Billing Date</h3>
                  <p className="text-gray-600">July 11, 2023</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <Button to="/account" fullWidth size="lg">
              Go to My Account
            </Button>
            
            <Button
              to="#" // Replace with search tutors page
              variant="outline"
              fullWidth
              size="lg"
              className="flex items-center justify-center"
            >
              <span>Schedule Your First Session</span>
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
          
          <p className="mt-8 text-sm text-gray-500">
            Need help? Contact us at{' '}
            <a href="mailto:studybridgelab@gmail.com" className="text-blue-600 hover:underline">
              studybridgelab@gmail.com
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}