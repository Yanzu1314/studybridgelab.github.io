import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

type Plan = 'basic' | 'plus' | 'premium' | null;

type SubscriptionContextType = {
  currentPlan: Plan;
  isSubscribed: boolean;
  isLoading: boolean;
  subscribe: (plan: Plan) => Promise<boolean>;
  unsubscribe: () => Promise<void>;
};

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export function SubscriptionProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [currentPlan, setCurrentPlan] = useState<Plan>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    // Load subscription status when user changes
    if (user) {
      // Mock API call - would be replaced with actual API call
      setIsLoading(true);
      const storedPlan = localStorage.getItem('subscription');
      if (storedPlan) {
        setCurrentPlan(storedPlan as Plan);
      }
      setIsLoading(false);
    } else {
      setCurrentPlan(null);
    }
  }, [user]);

  const subscribe = async (plan: Plan): Promise<boolean> => {
    setIsLoading(true);
    try {
      // Mock API call - would be replaced with actual API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setCurrentPlan(plan);
      localStorage.setItem('subscription', plan as string);
      return true;
    } catch (error) {
      console.error('Subscription failed:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const unsubscribe = async (): Promise<void> => {
    setIsLoading(true);
    try {
      // Mock API call - would be replaced with actual API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setCurrentPlan(null);
      localStorage.removeItem('subscription');
    } catch (error) {
      console.error('Unsubscribe failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SubscriptionContext.Provider
      value={{
        currentPlan,
        isSubscribed: !!currentPlan,
        isLoading,
        subscribe,
        unsubscribe,
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
}

export function useSubscription() {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
}