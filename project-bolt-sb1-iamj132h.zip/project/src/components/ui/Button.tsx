import React from 'react';
import { Link } from 'react-router-dom';
import clsx from 'clsx';

type ButtonProps = {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  to?: string;
  href?: string;
  onClick?: () => void;
  disabled?: boolean;
  fullWidth?: boolean;
  type?: 'button' | 'submit' | 'reset';
  className?: string;
};

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  to,
  href,
  onClick,
  disabled = false,
  fullWidth = false,
  type = 'button',
  className = '',
}: ButtonProps) {
  const baseStyles = clsx(
    'inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none',
    {
      'bg-blue-600 text-white hover:bg-blue-700 active:bg-blue-800': variant === 'primary',
      'bg-purple-600 text-white hover:bg-purple-700 active:bg-purple-800': variant === 'secondary',
      'border border-gray-300 bg-transparent hover:bg-gray-50 text-gray-700': variant === 'outline',
      'bg-transparent hover:bg-gray-100 text-gray-700': variant === 'ghost',
      'h-9 px-4 text-sm': size === 'sm',
      'h-10 px-5 text-base': size === 'md',
      'h-12 px-8 text-lg': size === 'lg',
      'w-full': fullWidth,
    },
    className
  );

  if (to) {
    return (
      <Link to={to} className={baseStyles}>
        {children}
      </Link>
    );
  }

  if (href) {
    return (
      <a href={href} className={baseStyles} target="_blank" rel="noopener noreferrer">
        {children}
      </a>
    );
  }

  return (
    <button
      type={type}
      className={baseStyles}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}