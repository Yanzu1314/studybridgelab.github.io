import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, BookOpen, User } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../ui/Button';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { isAuthenticated, user, logout } = useAuth();
  const location = useLocation();
  
  // Close mobile menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  // Handle scroll events to change navbar appearance
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        {/* Logo */}
        <Link 
          to="/" 
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700"
        >
          <BookOpen className="h-8 w-8" />
          <span className="font-bold text-xl">StudyBridge</span>
        </Link>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link 
            to="/become-a-tutor" 
            className="font-medium text-gray-700 hover:text-blue-600 transition-colors"
          >
            Become a Tutor
          </Link>
          <Link 
            to="/contact" 
            className="font-medium text-gray-700 hover:text-blue-600 transition-colors"
          >
            Contact
          </Link>
          
          {isAuthenticated ? (
            <div className="flex items-center space-x-4">
              <Button to="/account" variant="outline" size="sm">
                <User className="h-4 w-4 mr-2" />
                {user?.name}
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={logout}
              >
                Logout
              </Button>
            </div>
          ) : (
            <Button to="/auth" variant="primary" size="sm">
              Sign In
            </Button>
          )}
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t shadow-lg animate-fadeIn">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-3">
            <Link 
              to="/become-a-tutor" 
              className="py-3 px-4 font-medium text-gray-700 hover:bg-gray-50 rounded-md"
            >
              Become a Tutor
            </Link>
            <Link 
              to="/contact" 
              className="py-3 px-4 font-medium text-gray-700 hover:bg-gray-50 rounded-md"
            >
              Contact
            </Link>
            
            {isAuthenticated ? (
              <>
                <Link 
                  to="/account" 
                  className="py-3 px-4 font-medium text-gray-700 hover:bg-gray-50 rounded-md flex items-center"
                >
                  <User className="h-4 w-4 mr-2" />
                  My Account
                </Link>
                <button 
                  onClick={logout}
                  className="py-3 px-4 font-medium text-gray-700 hover:bg-gray-50 rounded-md text-left"
                >
                  Logout
                </button>
              </>
            ) : (
              <Link 
                to="/auth" 
                className="py-3 px-4 font-medium bg-blue-600 text-white hover:bg-blue-700 rounded-md text-center"
              >
                Sign In
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
}