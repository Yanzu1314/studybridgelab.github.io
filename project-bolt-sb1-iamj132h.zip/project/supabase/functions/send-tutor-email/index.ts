import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { email, type, name } = await req.json();

    if (!email || !type || !name) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Email templates
    const templates = {
      confirmation: {
        subject: 'StudyBridge Tutor Application Received',
        body: `Dear ${name},

Thank you for applying to become a tutor at StudyBridge! We have received your application and our team will review it within 3-5 business days.

You will receive another email once your application has been reviewed.

Best regards,
The StudyBridge Team`,
      },
      approval: {
        subject: 'Welcome to StudyBridge - Application Approved!',
        body: `Dear ${name},

Congratulations! Your application to become a tutor at StudyBridge has been approved.

You can now log in to your account and start helping students achieve their academic goals.

Best regards,
The StudyBridge Team`,
      },
    };

    const template = templates[type as keyof typeof templates];
    if (!template) {
      throw new Error('Invalid email type');
    }

    // Send email using Supabase's built-in email service
    const { error } = await supabaseClient.auth.admin.sendEmail(
      email,
      template.subject,
      template.body
    );

    if (error) throw error;

    return new Response(
      JSON.stringify({ message: 'Email sent successfully' }),
      { headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
});