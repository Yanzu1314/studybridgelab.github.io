/*
  # Create tutor applications table

  1. New Tables
    - `tutor_applications`
      - `id` (uuid, primary key)
      - `name` (text)
      - `email` (text)
      - `phone` (text)
      - `university` (text)
      - `graduation_year` (text)
      - `subjects` (text[])
      - `bio` (text)
      - `experience` (text)
      - `availability` (text[])
      - `status` (text) - 'pending', 'approved', 'rejected'
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `tutor_applications` table
    - Add policy for users to read their own applications
    - Add policy for users to create applications
*/

CREATE TABLE IF NOT EXISTS tutor_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  university text NOT NULL,
  graduation_year text NOT NULL,
  subjects text[] NOT NULL,
  bio text NOT NULL,
  experience text,
  availability text[] NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE tutor_applications ENABLE ROW LEVEL SECURITY;

-- Allow users to read their own applications
CREATE POLICY "Users can read own applications"
  ON tutor_applications
  FOR SELECT
  TO authenticated
  USING (auth.jwt()->>'email' = email);

-- Allow users to create applications
CREATE POLICY "Users can create applications"
  ON tutor_applications
  FOR INSERT
  TO authenticated
  WITH CHECK (true);